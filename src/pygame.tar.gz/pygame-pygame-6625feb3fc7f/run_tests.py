#!/usr/bin/env python

"""Run one or more Pygame unittest modules in the test directory

For command line options use the --help option.

"""

import test.__main__

